export class appUsersAuth {
  
 public userName:string="";
public  isAuthinticated:boolean=false;
public  bearerToken:string="";
  public canViewVehicle:boolean=false;
  public canViewRide:boolean=false;
  public canViewWallet:boolean=false;
  public canViewSettings:boolean=false;
  public isRoleAdmin:boolean=false;
  
  
}