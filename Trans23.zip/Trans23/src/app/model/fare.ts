

export class Fare {
 public   id:LongRange;
 public  estimatedFare:LongRange;
 public   totalFare:LongRange;
 public   driverAllowance:LongRange;
 public  perHrAllowance:LongRange;
 public   extraKmFee:LongRange;
 public   totalKM:LongRange;
 public  totalKMTravelled:LongRange;

}